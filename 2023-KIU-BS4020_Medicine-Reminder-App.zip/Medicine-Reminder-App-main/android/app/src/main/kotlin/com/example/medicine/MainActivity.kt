package com.example.medicine

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
