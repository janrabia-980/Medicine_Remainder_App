import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart' if (dart.library.html) 'package:sqflite/sqflite.dart';
import '../models/medicine.dart';

class DatabaseHelper {
  static final DatabaseHelper _instance = DatabaseHelper._internal();
  factory DatabaseHelper() => _instance;
  DatabaseHelper._internal();

  static Database? _database;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<Database> _initDatabase() async {
    // On desktop platforms use the ffi implementation
    if (!kIsWeb && (Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      // initialize ffi implementation
      sqfliteFfiInit();
      databaseFactory = databaseFactoryFfi;
    }

    String path = join(await getDatabasesPath(), 'medicine.db');
    final db = await openDatabase(
      path,
      version: 3,
      onCreate: _onCreate,
      onUpgrade: (db, oldVersion, newVersion) async {
        if (oldVersion < 2) {
          // Add new columns if upgrading from version 1 to 2
          try {
            await db.execute("ALTER TABLE medicines ADD COLUMN notes TEXT");
          } catch (_) {}
          try {
            await db.execute("ALTER TABLE medicines ADD COLUMN form TEXT");
          } catch (_) {}
          try {
            await db.execute("ALTER TABLE medicines ADD COLUMN start_date TEXT");
          } catch (_) {}
          try {
            await db.execute("ALTER TABLE medicines ADD COLUMN end_date TEXT");
          } catch (_) {}
          try {
            await db.execute("ALTER TABLE medicines ADD COLUMN notify INTEGER");
          } catch (_) {}
        }
        if (oldVersion < 3) {
          try {
            await db.execute("ALTER TABLE medicines ADD COLUMN taken INTEGER DEFAULT 0");
          } catch (_) {}
        }
      },
    );

    // Ensure schema has all expected columns (helps when DB was created by an older version)
    await _ensureSchema(db);
    return db;
  }

  Future<void> _ensureSchema(Database db) async {
    try {
      // Check if table exists
      final tables = await db.rawQuery("SELECT name FROM sqlite_master WHERE type='table' AND name='medicines'");
      if (tables.isEmpty) {
        await _onCreate(db, 3);
        return;
      }

      final info = await db.rawQuery("PRAGMA table_info('medicines')");
      final existing = <String>{};
      for (final row in info) {
        final name = row['name'] as String?;
        if (name != null) existing.add(name);
      }

      final needed = <String, String>{
        'notes': 'TEXT',
        'form': 'TEXT',
        'start_date': 'TEXT',
        'end_date': 'TEXT',
        'notify': 'INTEGER',
        'taken': 'INTEGER DEFAULT 0',
      };

      for (final entry in needed.entries) {
        if (!existing.contains(entry.key)) {
          try {
            await db.execute("ALTER TABLE medicines ADD COLUMN ${entry.key} ${entry.value}");
          } catch (_) {}
        }
      }
    } catch (_) {
      // ignore migration errors to avoid crashing the app
    }
  }

  Future<void> _onCreate(Database db, int version) async {
    await db.execute('''
      CREATE TABLE medicines (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT,
        dosage TEXT,
        time TEXT,
        frequency TEXT,
        notes TEXT,
        form TEXT,
        start_date TEXT,
        end_date TEXT,
        notify INTEGER
        ,
        taken INTEGER DEFAULT 0
      )
    ''');
  }

  Future<int> insertMedicine(Medicine medicine) async {
    Database db = await database;
    return await db.insert('medicines', medicine.toMap());
  }

  Future<List<Medicine>> getMedicines() async {
    Database db = await database;
    List<Map<String, dynamic>> maps = await db.query('medicines');
    return List.generate(maps.length, (i) => Medicine.fromMap(maps[i]));
  }

  Future<int> updateMedicine(Medicine medicine) async {
    Database db = await database;
    return await db.update(
      'medicines',
      medicine.toMap(),
      where: 'id = ?',
      whereArgs: [medicine.id],
    );
  }

  Future<int> deleteMedicine(int id) async {
    Database db = await database;
    return await db.delete('medicines', where: 'id = ?', whereArgs: [id]);
  }
}