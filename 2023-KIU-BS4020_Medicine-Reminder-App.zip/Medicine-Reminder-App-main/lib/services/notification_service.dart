import 'dart:async';
import 'dart:io' show Platform;

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import 'package:timezone/timezone.dart' as tz;
import 'package:timezone/data/latest_all.dart' as tzdata;
import 'database_helper.dart';

class NotificationService {
  static final FlutterLocalNotificationsPlugin _notificationsPlugin = FlutterLocalNotificationsPlugin();
  static bool _initialized = false;
  static final Map<int, Timer> _timers = {};
  static int? _playingId;

  // background scheduler fields for desktop fallback
  static Timer? _timer;
  static final Map<int, DateTime> _lastNotified = {};

  static Future<void> initialize() async {
    if (_initialized) return;
    try {
      tzdata.initializeTimeZones();
      const AndroidInitializationSettings androidSettings = AndroidInitializationSettings('@mipmap/ic_launcher');
      const InitializationSettings settings = InitializationSettings(android: androidSettings);
      await _notificationsPlugin.initialize(settings);
      _initialized = true;
      // start background scheduler on desktop where zonedSchedule may be unimplemented
      if (!Platform.isAndroid && !Platform.isIOS) {
        _startBackgroundScheduler();
      }
    } catch (_) {
      // allow app to continue even if notifications can't be initialized
    }
  }

  static Future<void> scheduleNotification(int id, String title, String body, DateTime time) async {
    try {
      if (Platform.isAndroid || Platform.isIOS) {
        // Prefer zonedSchedule on supported platforms; fallback to a Timer for desktop
        try {
          final androidDetails = AndroidNotificationDetails(
            'medicine_channel',
            'Medicine Reminders',
            importance: Importance.max,
            priority: Priority.high,
            playSound: true,
            // Use default sound; custom sound would require adding raw resource
            enableVibration: true,
            ticker: 'Medicine Reminder',
          );
          final iosDetails = DarwinNotificationDetails(
            presentSound: true,
            sound: 'default',
          );
          await _notificationsPlugin.zonedSchedule(
            id,
            title,
            body,
            tz.TZDateTime.from(time, tz.local),
            NotificationDetails(android: androidDetails, iOS: iosDetails),
            androidScheduleMode: AndroidScheduleMode.exactAllowWhileIdle,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            matchDateTimeComponents: DateTimeComponents.time,
          );
        } on UnimplementedError catch (_) {
          // zonedSchedule not implemented on this platform (desktop); fall back to Timer
          final next = _nextOccurrence(time);
          final diff = next.difference(DateTime.now());
          if (diff.isNegative) return;
          // Clear any existing timer for this id
          _timers[id]?.cancel();
          _timers[id] = Timer(diff, () async {
            await showNotification(id, title, body);
          });
        } catch (e) {
          // Some platforms may still throw; try fallback Timer
          final next = _nextOccurrence(time);
          final diff = next.difference(DateTime.now());
          if (diff.isNegative) return;
          _timers[id]?.cancel();
          _timers[id] = Timer(diff, () async {
            await showNotification(id, title, body);
          });
        }
      } else {
        // desktop: schedule a local timer for the next occurrence as a fallback
        final next = _nextOccurrence(time);
        final diff = next.difference(DateTime.now());
        if (diff.isNegative) return;
        _timers[id]?.cancel();
        _timers[id] = Timer(diff, () async {
          await showNotification(id, title, body);
        });
      }
    } catch (_) {
      // fallback to immediate notification if scheduling fails
      await showNotification(id + 100000, title, body);
    }
  }

  static Future<void> showNotification(int id, String title, String body) async {
    try {
      final androidDetails = AndroidNotificationDetails(
        'medicine_channel',
        'Medicine Reminders',
        importance: Importance.max,
        priority: Priority.high,
        playSound: true,
        enableVibration: true,
        ticker: 'Medicine Reminder',
      );
      final iosDetails = DarwinNotificationDetails(presentSound: true, sound: 'default');
      await _notificationsPlugin.show(
        id,
        title,
        body,
        NotificationDetails(android: androidDetails, iOS: iosDetails),
      );
      // start ringtone when showing notification (app running)
      try {
        startRingtone(id);
      } catch (_) {}
    } catch (_) {
      // ignore if show is not available on platform
    }
  }

  static DateTime _nextOccurrence(DateTime time) {
    final now = DateTime.now();
    final candidate = DateTime(now.year, now.month, now.day, time.hour, time.minute);
    if (candidate.isBefore(now)) {
      return candidate.add(const Duration(days: 1));
    }
    return candidate;
  }

  static Future<void> cancelNotification(int id) async {
    try {
      // cancel any timer fallback
      _timers[id]?.cancel();
      _timers.remove(id);
      // stop ringtone if playing for this id
      if (_playingId == id) {
        stopRingtone();
      }
      if (_initialized) {
        await _notificationsPlugin.cancel(id);
      }
    } catch (_) {
      // ignore cancellation errors
    }
  }

  static void startRingtone(int id) {
    try {
      // stop any existing
      if (_playingId != null && _playingId != id) {
        stopRingtone();
      }
      _playingId = id;
      FlutterRingtonePlayer.play(
        android: AndroidSounds.alarm,
        ios: IosSounds.alarm,
        looping: true, // loop until stopped
        asAlarm: true,
      );
    } catch (_) {}
  }

  static void stopRingtone() {
    try {
      FlutterRingtonePlayer.stop();
      _playingId = null;
    } catch (_) {}
  }

  static Future<void> cancelAllNotifications() async {
    try {
      _timers.values.forEach((t) => t.cancel());
      _timers.clear();
      if (_initialized) await _notificationsPlugin.cancelAll();
    } catch (_) {}
  }

  static void _startBackgroundScheduler() {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(minutes: 1), (_) async {
      await _checkDue();
    });
    // run once immediately
    _checkDue();
  }

  static Future<void> _checkDue() async {
    try {
      final now = DateTime.now();
      final medicines = await DatabaseHelper().getMedicines();
      for (final m in medicines) {
        if (m.id == null) continue;
        if (!m.notify) continue;
        if (m.startDate != null && now.isBefore(m.startDate!)) continue;
        if (m.endDate != null && now.isAfter(m.endDate!)) continue;
        if (m.time.hour == now.hour && m.time.minute == now.minute) {
          final last = _lastNotified[m.id!];
          if (last != null && last.year == now.year && last.month == now.month && last.day == now.day && last.hour == now.hour && last.minute == now.minute) {
            continue;
          }
          await showNotification(m.id! + 200000, 'Medicine Reminder', 'Time to take ${m.name}');
          _lastNotified[m.id!] = now;
        }
      }
    } catch (_) {
      // ignore errors in background check
    }
  }
}