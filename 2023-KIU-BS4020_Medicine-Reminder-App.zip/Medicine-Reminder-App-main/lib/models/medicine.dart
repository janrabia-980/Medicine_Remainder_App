class Medicine {
  int? id;
  String name;
  String dosage;
  DateTime time;
  String frequency; // e.g., 'Daily', 'Weekly'
  String? notes;
  String form; // e.g., Pill, Syrup, Injection
  DateTime? startDate;
  DateTime? endDate;
  bool notify;
  bool taken;

  Medicine({
    this.id,
    required this.name,
    required this.dosage,
    required this.time,
    required this.frequency,
    this.notes,
    this.form = 'Pill',
    this.startDate,
    this.endDate,
    this.notify = true,
    this.taken = false,
  });

  // Convert to Map for SQLite
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'dosage': dosage,
      'time': time.toIso8601String(),
      'frequency': frequency,
      'notes': notes,
      'form': form,
      'start_date': startDate?.toIso8601String(),
      'end_date': endDate?.toIso8601String(),
      'notify': notify ? 1 : 0,
      'taken': taken ? 1 : 0,
    };
  }

  // From Map
  factory Medicine.fromMap(Map<String, dynamic> map) {
    return Medicine(
      id: map['id'],
      name: map['name'],
      dosage: map['dosage'],
      time: DateTime.parse(map['time']),
      frequency: map['frequency'],
      notes: map['notes'],
      form: map['form'] ?? 'Pill',
      startDate: map['start_date'] != null ? DateTime.parse(map['start_date']) : null,
      endDate: map['end_date'] != null ? DateTime.parse(map['end_date']) : null,
      notify: map['notify'] == null ? true : (map['notify'] == 1),
      taken: map['taken'] == null ? false : (map['taken'] == 1),
    );
  }
}