import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../models/medicine.dart';
import '../services/database_helper.dart';
import '../services/notification_service.dart';
import 'add_edit_medicine_screen.dart';
import 'medicine_details_screen.dart';
import 'settings_screen.dart';
import '../widgets/animated_button.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  List<Medicine> _medicines = [];

  @override
  void initState() {
    super.initState();
    NotificationService.initialize();
    _loadMedicines();
  }

  void _loadMedicines() async {
    _medicines = await DatabaseHelper().getMedicines();
    setState(() {});
  }

  void _deleteMedicine(int id) async {
    await DatabaseHelper().deleteMedicine(id);
    await NotificationService.cancelNotification(id);
    _loadMedicines();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('SMAN'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const SettingsScreen()),
            ),
          ),
        ],
      ),
      body: _medicines.isEmpty
          ? Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: const [
                  Icon(Icons.medication, size: 48),
                  SizedBox(height: 10),
                  Text('No medicines added yet.'),
                ],
              ),
            )
          : ListView.builder(
              itemCount: _medicines.length,
              itemBuilder: (context, index) {
                final medicine = _medicines[index];
                return Container(
                  margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Colors.teal.shade50, Colors.white],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(12),
                    boxShadow: [
                      BoxShadow(color: Colors.black12, blurRadius: 6, offset: Offset(0, 3)),
                    ],
                  ),
                  child: ListTile(
                    contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                    leading: CircleAvatar(
                      radius: 26,
                      backgroundColor: medicine.taken ? Colors.green.shade100 : Colors.teal.shade100,
                      child: Icon(
                        medicine.taken ? Icons.check : Icons.medication_rounded,
                        color: medicine.taken ? Colors.green.shade800 : Colors.teal.shade800,
                        size: 28,
                      ),
                    ),
                    title: Text(medicine.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const SizedBox(height: 4),
                        Text(medicine.dosage),
                        const SizedBox(height: 6),
                        Row(
                          children: [
                            Chip(
                              label: Text('${medicine.time.hour.toString().padLeft(2, '0')}:${medicine.time.minute.toString().padLeft(2, '0')}'),
                              backgroundColor: Colors.teal.shade50,
                              visualDensity: VisualDensity.compact,
                            ),
                            const SizedBox(width: 8),
                            Chip(
                              label: Text(medicine.frequency),
                              backgroundColor: Colors.grey.shade100,
                              visualDensity: VisualDensity.compact,
                            ),
                          ],
                        ),
                      ],
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        // Toggle notifications for this medicine
                        IconButton(
                          tooltip: medicine.notify ? 'Disable notifications' : 'Enable notifications',
                          icon: Icon(medicine.notify ? Icons.notifications_active : Icons.notifications_off),
                          onPressed: () async {
                            medicine.notify = !medicine.notify;
                            await DatabaseHelper().updateMedicine(medicine);
                            if (medicine.id != null) {
                              if (medicine.notify) {
                                // schedule next occurrence
                                await NotificationService.scheduleNotification(
                                  medicine.id!,
                                  'Medicine Reminder',
                                  'Time to take ${medicine.name}',
                                  medicine.time,
                                );
                                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notifications enabled')));
                              } else {
                                // cancel scheduled/instant notifications
                                await NotificationService.cancelNotification(medicine.id!);
                                await NotificationService.cancelNotification(medicine.id! + 100000);
                                await NotificationService.cancelNotification(medicine.id! + 200000);
                                if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notifications disabled')));
                              }
                            }
                            setState(() {});
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.edit),
                          onPressed: () async {
                            final saved = await Navigator.push<bool?>(
                              context,
                              MaterialPageRoute(builder: (context) => AddEditMedicineScreen(medicine: medicine)),
                            );
                            _loadMedicines();
                            if (saved == true && context.mounted) {
                              ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Medicine updated')));
                            }
                          },
                        ),
                        IconButton(
                          icon: const Icon(Icons.delete),
                          onPressed: () => _deleteMedicine(medicine.id!),
                        ),
                      ],
                    ),
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => MedicineDetailsScreen(medicine: medicine),
                      ),
                    ),
                  ),
                ).animate().fadeIn(delay: (index * 100).ms);
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () async {
          final saved = await Navigator.push<bool?>(
            context,
            MaterialPageRoute(builder: (context) => const AddEditMedicineScreen()),
          );
          _loadMedicines();
          if (saved == true && context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Medicine saved')));
          }
        },
        child: const Icon(Icons.add),
      ).animate().scale(begin: const Offset(0.5, 0.5)),
    );
  }
}