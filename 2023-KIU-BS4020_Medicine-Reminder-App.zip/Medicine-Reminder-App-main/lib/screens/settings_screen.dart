import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import '../widgets/animated_button.dart';
import '../services/theme_service.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  bool _notificationsEnabled = true; // persisted value
  bool _notificationsTemp = true; // temp change until Save
  bool _isDarkSelected = false; // temp selection until Save

  @override
  void initState() {
    super.initState();
    _notificationsTemp = _notificationsEnabled;
    _isDarkSelected = ThemeService.themeModeNotifier.value == ThemeMode.dark;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            Icon(
              Icons.settings,
              size: 120,
              color: Theme.of(context).colorScheme.primary,
            ).animate().fadeIn(duration: 1.seconds).scale(),
            const SizedBox(height: 20),
            SwitchListTile(
              title: const Text('Enable Notifications'),
              value: _notificationsTemp,
              onChanged: (bool value) {
                setState(() {
                  _notificationsTemp = value;
                });
              },
            ).animate().fadeIn(delay: 500.ms),
            SwitchListTile(
              title: const Text('Dark Theme'),
              value: _isDarkSelected,
              onChanged: (bool value) {
                setState(() {
                  _isDarkSelected = value;
                });
              },
            ).animate().fadeIn(delay: 600.ms),
            const SizedBox(height: 20),
            const Text(
              'Manage your app preferences here. Notifications help remind you of medicines.',
              textAlign: TextAlign.center,
            ).animate().fadeIn(delay: 700.ms),
            const SizedBox(height: 40),
            AnimatedButton(
              text: 'Save Settings',
              onPressed: () async {
                // Apply changes only when Save pressed
                _notificationsEnabled = _notificationsTemp;
                await ThemeService.setTheme(_isDarkSelected);
                // persist notification setting
                try {
                  final prefs = await SharedPreferences.getInstance();
                  await prefs.setBool('notificationsEnabled', _notificationsEnabled);
                } catch (_) {}
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Settings saved!')),
                );
                Navigator.pop(context);
              },
            ).animate().fadeIn(delay: 900.ms),
          ],
        ),
      ),
    );
  }
}