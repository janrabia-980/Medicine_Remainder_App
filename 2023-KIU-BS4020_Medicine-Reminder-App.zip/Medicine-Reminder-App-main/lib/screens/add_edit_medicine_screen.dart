import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../models/medicine.dart';
import '../services/database_helper.dart';
import '../services/notification_service.dart';
import '../widgets/animated_button.dart';

class AddEditMedicineScreen extends StatefulWidget {
  final Medicine? medicine;

  const AddEditMedicineScreen({super.key, this.medicine});

  @override
  _AddEditMedicineScreenState createState() => _AddEditMedicineScreenState();
}

class _AddEditMedicineScreenState extends State<AddEditMedicineScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _nameController;
  late TextEditingController _dosageController;
  late TextEditingController _notesController;
  late DateTime _selectedTime;
  String _frequency = 'Daily';
  String _form = 'Pill';
  DateTime? _startDate;
  DateTime? _endDate;
  bool _notify = true;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.medicine?.name ?? '');
    _dosageController = TextEditingController(text: widget.medicine?.dosage ?? '');
    _notesController = TextEditingController(text: widget.medicine?.notes ?? '');
    _selectedTime = widget.medicine?.time ?? DateTime.now();
    _frequency = widget.medicine?.frequency ?? 'Daily';
    _form = widget.medicine?.form ?? 'Pill';
    _startDate = widget.medicine?.startDate;
    _endDate = widget.medicine?.endDate;
    _notify = widget.medicine?.notify ?? true;
  }

  void _saveMedicine() async {
    if (_formKey.currentState!.validate()) {
      final medicine = Medicine(
        id: widget.medicine?.id,
        name: _nameController.text,
        dosage: _dosageController.text,
        time: _selectedTime,
        frequency: _frequency,
        notes: _notesController.text.isEmpty ? null : _notesController.text,
        form: _form,
        startDate: _startDate,
        endDate: _endDate,
        notify: _notify,
      );

      if (widget.medicine == null) {
        final int newId = await DatabaseHelper().insertMedicine(medicine);
        medicine.id = newId;
        if (medicine.notify) {
          await NotificationService.scheduleNotification(
            newId,
            'Medicine Reminder',
            'Time to take ${medicine.name}',
            medicine.time,
          );
        }
        // show immediate save confirmation notification
        await NotificationService.showNotification(
          newId + 100000, // separate id for immediate notice
          'SMAN',
          'Saved ${medicine.name}',
        );
      } else {
        await DatabaseHelper().updateMedicine(medicine);
        if (medicine.notify && medicine.id != null) {
          await NotificationService.scheduleNotification(
            medicine.id!,
            'Medicine Reminder',
            'Time to take ${medicine.name}',
            medicine.time,
          );
        }
      }

      if (context.mounted) Navigator.pop(context, true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.medicine == null ? 'Add Medicine' : 'Edit Medicine')),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(20.0),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Medicine Name'),
                  validator: (value) => value!.isEmpty ? 'Required' : null,
                ).animate().fadeIn(),
                TextFormField(
                  controller: _dosageController,
                  decoration: const InputDecoration(labelText: 'Dosage'),
                  validator: (value) => value!.isEmpty ? 'Required' : null,
                ).animate().fadeIn(delay: 200.ms),
                TextFormField(
                  controller: _notesController,
                  decoration: const InputDecoration(labelText: 'Notes (optional)'),
                  maxLines: 2,
                ).animate().fadeIn(delay: 250.ms),
                const SizedBox(height: 8),
                ListTile(
                  title: const Text('Time'),
                  subtitle: Text(DateFormat('HH:mm').format(_selectedTime)),
                  trailing: const Icon(Icons.access_time),
                  onTap: () async {
                    final time = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_selectedTime));
                    if (time != null) {
                      setState(() {
                        _selectedTime = DateTime(_selectedTime.year, _selectedTime.month, _selectedTime.day, time.hour, time.minute);
                      });
                    }
                  },
                ).animate().fadeIn(delay: 400.ms),
                DropdownButtonFormField<String>(
                  value: _frequency,
                  items: ['Daily', 'Weekly', 'Monthly'].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (newValue) {
                    setState(() {
                      _frequency = newValue!;
                    });
                  },
                  decoration: const InputDecoration(labelText: 'Frequency'),
                ).animate().fadeIn(delay: 600.ms),
                const SizedBox(height: 8),
                DropdownButtonFormField<String>(
                  value: _form,
                  items: ['Pill', 'Syrup', 'Injection', 'Inhaler', 'Other'].map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (newValue) => setState(() => _form = newValue!),
                  decoration: const InputDecoration(labelText: 'Form'),
                ).animate().fadeIn(delay: 700.ms),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: ListTile(
                        title: const Text('Start Date'),
                        subtitle: Text(_startDate != null ? DateFormat('yyyy-MM-dd').format(_startDate!) : 'Not set'),
                        onTap: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: _startDate ?? DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                          );
                          if (date != null) setState(() => _startDate = date);
                        },
                      ),
                    ),
                    Expanded(
                      child: ListTile(
                        title: const Text('End Date'),
                        subtitle: Text(_endDate != null ? DateFormat('yyyy-MM-dd').format(_endDate!) : 'Not set'),
                        onTap: () async {
                          final date = await showDatePicker(
                            context: context,
                            initialDate: _endDate ?? DateTime.now(),
                            firstDate: DateTime(2000),
                            lastDate: DateTime(2100),
                          );
                          if (date != null) setState(() => _endDate = date);
                        },
                      ),
                    ),
                  ],
                ),
                SwitchListTile(
                  title: const Text('Enable Notification'),
                  value: _notify,
                  onChanged: (v) => setState(() => _notify = v),
                ),
                const SizedBox(height: 20),
                AnimatedButton(
                  text: 'Save Medicine',
                  onPressed: _saveMedicine,
                ).animate().fadeIn(delay: 800.ms),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// helper removed