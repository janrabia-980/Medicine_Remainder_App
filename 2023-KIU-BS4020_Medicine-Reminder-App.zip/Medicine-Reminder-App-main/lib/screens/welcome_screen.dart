import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'home_screen.dart';
import '../widgets/animated_button.dart';

class WelcomeScreen extends StatelessWidget {
  const WelcomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              width: double.infinity,
              alignment: Alignment.center,
              child: Icon(
                Icons.local_hospital,
                size: 200,
                color: Theme.of(context).colorScheme.primary,
              ),
            ).animate().slideX(begin: -1, duration: 1.seconds),
            const SizedBox(height: 20),
            const Text(
              'Welcome to SMAN!',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ).animate().fadeIn(delay: 500.ms),
            const SizedBox(height: 10),
            const Text(
              'Stay on top of your medication schedule with reminders and tracking.',
              textAlign: TextAlign.center,
            ).animate().fadeIn(delay: 1.seconds),
            const SizedBox(height: 40),
            AnimatedButton(
              text: 'Get Started',
              onPressed: () {
                Navigator.pushReplacement(
                  context,
                  MaterialPageRoute(builder: (context) => const HomeScreen()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}