import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:intl/intl.dart';
import '../models/medicine.dart';
import '../services/database_helper.dart';
import '../services/notification_service.dart';
import 'add_edit_medicine_screen.dart';
import '../widgets/animated_button.dart';

class MedicineDetailsScreen extends StatelessWidget {
  final Medicine medicine;

  const MedicineDetailsScreen({super.key, required this.medicine});
                              
  void _deleteMedicine(BuildContext context) async {
    await DatabaseHelper().deleteMedicine(medicine.id!);
    await NotificationService.cancelNotification(medicine.id!);
    if (context.mounted) {  // Added: Check if context is still mounted
      Navigator.pop(context); // Go back to home
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Medicine Details')),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              height: 150,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.primary.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(
                Icons.medication_liquid,
                size: 80,
                color: Theme.of(context).colorScheme.primary,
              ),
            ).animate().fadeIn(duration: 1.seconds).scale(),
            const SizedBox(height: 20),
            Text(
              'Name: ${medicine.name}',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ).animate().fadeIn(delay: 200.ms),
            const SizedBox(height: 10),
            Text('Dosage: ${medicine.dosage}').animate().fadeIn(delay: 400.ms),
            const SizedBox(height: 10),
            Text('Form: ${medicine.form}').animate().fadeIn(delay: 450.ms),
            const SizedBox(height: 10),
            if (medicine.notes != null && medicine.notes!.isNotEmpty) Text('Notes: ${medicine.notes}').animate().fadeIn(delay: 500.ms),
            const SizedBox(height: 10),
            Text('Time: ${DateFormat('HH:mm').format(medicine.time)}').animate().fadeIn(delay: 600.ms),
            const SizedBox(height: 10),
            Text('Frequency: ${medicine.frequency}').animate().fadeIn(delay: 800.ms),
            const SizedBox(height: 10),
            if (medicine.startDate != null) Text('Start: ${DateFormat('yyyy-MM-dd').format(medicine.startDate!)}').animate().fadeIn(delay: 900.ms),
            if (medicine.endDate != null) Text('End: ${DateFormat('yyyy-MM-dd').format(medicine.endDate!)}').animate().fadeIn(delay: 1000.ms),
            const SizedBox(height: 10),
            Text('Notifications: ${medicine.notify ? 'Enabled' : 'Disabled'}').animate().fadeIn(delay: 1100.ms),
            const SizedBox(height: 40),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                AnimatedButton(
                  text: 'Edit',
                  onPressed: () async {
                    await Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => AddEditMedicineScreen(medicine: medicine),
                      ),
                    );
                    if (context.mounted) {  // Added: Check if context is still mounted
                      Navigator.pop(context); // Refresh by going back
                    }
                  },
                ).animate().slideX(begin: -1, delay: 1.seconds),  // Changed: slideInFromLeft -> slideX(begin: -1)
                AnimatedButton(
                  text: 'Stop',
                  onPressed: () async {
                    if (medicine.id != null) {
                      await NotificationService.cancelNotification(medicine.id!);
                      await NotificationService.cancelNotification(medicine.id! + 100000);
                      await NotificationService.cancelNotification(medicine.id! + 200000);
                      if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Notification stopped')));
                    }
                  },
                ).animate().slideX(begin: 0.5, delay: 1.seconds),
                AnimatedButton(
                  text: 'Delete',
                  onPressed: () => _deleteMedicine(context),
                ).animate().slideX(begin: 1, delay: 1.seconds),  // Changed: slideInFromRight -> slideX(begin: 1)
              ],
            ),
          ],
        ),
      ),
    );
  }
}